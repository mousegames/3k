import sys

lines = []
main = []

filename = sys.argv[1]

with open(filename, 'r') as file:
	for line in file:
		lines.append(line)

for line in range(len(lines)):
	if lines[line] == 'str\n':
		var = lines[line + 1].strip()
		main.append(var)
	elif lines[line] == 'num\n':
		n1 = int(lines[line + 1].strip())
		n2 = int(lines[line + 2].strip())
		
		num = n1 + n2
		main.append(num) 
	
	if lines[line] == 'out\n':
		index = int(lines[line + 1].strip())
		print(main[index])

